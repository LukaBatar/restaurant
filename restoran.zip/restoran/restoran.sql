-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2019 at 07:59 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restoran`
--

-- --------------------------------------------------------

--
-- Table structure for table `admini`
--

CREATE TABLE `admini` (
  `idadmina` int(11) NOT NULL,
  `imeadmina` varchar(255) NOT NULL,
  `prezimeadmina` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admini`
--

INSERT INTO `admini` (`idadmina`, `imeadmina`, `prezimeadmina`, `username`, `password`) VALUES
(1, 'Luka', 'Batar', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `jelovnik`
--

CREATE TABLE `jelovnik` (
  `idjela` int(11) NOT NULL,
  `nazivjela` varchar(255) NOT NULL,
  `opisjela` text NOT NULL,
  `cenajela` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jelovnik`
--

INSERT INTO `jelovnik` (`idjela`, `nazivjela`, `opisjela`, `cenajela`) VALUES
(15, 'Govedji prsut', 'Najfiniji govedji prsut', 520),
(16, 'Bruskete', 'Sveze meseni brusketi', 230),
(17, 'Pileca salata sa povrcem', 'Mesano povrce sa piletinom sa domace farme', 420),
(18, 'Grcka salata', 'Vise od obicne grcke salate', 350),
(19, 'Teleca krem corba', 'Domaca krem corba', 150),
(20, 'Pileca supa sa rezancima', 'Topla supa za srecan stomak', 170),
(21, 'Grilovano povrce', 'Pravi izbor za svakog vegeterijanca', 320),
(22, 'Pastrmka', 'Domaca pastrmka', 1700),
(23, 'Pohovana piletina', 'Za masan i sit obrok', 720),
(24, 'Punjeni cevapi', 'Specijalni cevapi punjeni tajnim mixom', 900),
(25, 'Leskovacka muckalica', 'Samo za spremne', 700),
(26, 'Pomfrit', 'Krompi sa sela', 150);

-- --------------------------------------------------------

--
-- Table structure for table `kartapica`
--

CREATE TABLE `kartapica` (
  `idpica` int(11) NOT NULL,
  `nazivpica` varchar(255) NOT NULL,
  `opispica` text NOT NULL,
  `cenapica` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kartapica`
--

INSERT INTO `kartapica` (`idpica`, `nazivpica`, `opispica`, `cenapica`) VALUES
(7, 'Pivo 0.33', 'Malo toceno pivo', 160),
(8, 'Pivo 0.5', 'Veliko toceno pivo', 200),
(9, 'Pelinkovac', '0.03', 170),
(10, 'Vinjak', '0.03', 170),
(11, 'Rakija kajsija cica Jova', '0.03', 220),
(12, 'Next sok', '0.33', 190),
(13, 'Coca-cola', '0.33', 150),
(14, 'Limunada', '0.33', 210);

-- --------------------------------------------------------

--
-- Table structure for table `racuni`
--

CREATE TABLE `racuni` (
  `idracuna` int(11) NOT NULL,
  `idstola` int(11) NOT NULL,
  `brojracuna` int(11) NOT NULL,
  `naziv` varchar(255) NOT NULL,
  `cena1` int(11) NOT NULL,
  `kolicina` varchar(255) NOT NULL,
  `cena2` int(11) NOT NULL,
  `vreme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `racuni`
--

INSERT INTO `racuni` (`idracuna`, `idstola`, `brojracuna`, `naziv`, `cena1`, `kolicina`, `cena2`, `vreme`) VALUES
(2, 7, 1, 'sushi', 3500, '2', 7000, '2019-06-19 15:55:19'),
(3, 7, 1, 'uzo', 400, '3', 1200, '2019-06-19 15:55:19'),
(4, 7, 2, 'sushi', 3500, '2', 7000, '2019-06-19 15:56:19'),
(5, 7, 2, 'uzo', 400, '3', 1200, '2019-06-19 15:56:19'),
(6, 2, 3, 'sushi', 3500, '2', 7000, '2019-06-19 16:04:25'),
(7, 2, 3, 'uzo', 400, '3', 1200, '2019-06-19 16:04:25'),
(8, 2, 4, 'sushi', 3500, '2', 7000, '2019-06-19 16:05:25'),
(9, 7, 5, 'uzo', 400, '3', 1200, '2019-06-19 16:11:55'),
(10, 3, 6, 'govedina', 1200, '1', 1200, '2019-06-19 16:13:44'),
(11, 3, 6, 'uzo', 400, '1', 400, '2019-06-19 16:13:44'),
(12, 3, 7, 'uzo', 400, '1', 400, '2019-06-19 16:14:36'),
(13, 3, 7, 'uzo', 400, '1', 400, '2019-06-19 16:14:36'),
(14, 3, 7, 'uzo', 400, '1', 400, '2019-06-19 16:14:36'),
(15, 3, 7, 'uzo', 400, '1', 400, '2019-06-19 16:14:36'),
(16, 3, 7, 'uzo', 400, '1', 400, '2019-06-19 16:14:36'),
(17, 3, 7, 'uzo', 400, '1', 400, '2019-06-19 16:14:36'),
(18, 3, 8, 'uzo', 400, '1', 400, '2019-06-19 16:18:46'),
(19, 3, 8, 'sushi', 3500, '2', 7000, '2019-06-19 16:18:46'),
(20, 3, 9, 'sushi', 3500, '2', 7000, '2019-06-19 16:20:54'),
(21, 5, 10, 'sushi', 3500, '2', 7000, '2019-06-19 16:23:51'),
(22, 5, 10, 'sushi', 3500, '2', 7000, '2019-06-19 16:23:51'),
(23, 5, 10, 'govedina', 1200, '3', 3600, '2019-06-19 16:23:51'),
(24, 7, 11, 'sushi', 3500, '2', 7000, '2019-06-19 16:24:26'),
(25, 7, 11, 'govedina', 1200, '2', 2400, '2019-06-19 16:24:26'),
(26, 2, 12, 'govedina', 1200, '3', 3600, '2019-06-19 16:28:35'),
(27, 2, 13, 'uzo', 400, '2', 800, '2019-06-19 16:31:48'),
(28, 2, 13, 'govedina', 1200, '2', 2400, '2019-06-19 16:31:48'),
(29, 3, 14, 'Govedji prsut', 520, '3', 1560, '2019-06-25 16:50:01'),
(30, 3, 14, 'Rakija kajsija cica Jova', 220, '2', 440, '2019-06-25 16:50:01'),
(31, 3, 14, 'Pelinkovac', 170, '3', 510, '2019-06-25 16:50:01'),
(32, 6, 15, 'Bruskete', 230, '3', 690, '2019-06-25 16:51:11'),
(33, 2, 16, 'Pivo 0.33', 160, '3', 480, '2019-07-03 20:36:45'),
(34, 7, 17, 'Pivo 0.33', 160, '2', 320, '2019-07-13 09:59:30'),
(35, 6, 18, 'Govedji prsut', 520, '2', 1040, '2019-07-13 10:03:36'),
(36, 6, 19, 'Pivo 0.33', 160, '2', 320, '2019-07-13 10:04:32'),
(37, 11, 20, 'Grilovano povrce', 320, '2', 640, '2019-07-21 19:32:13'),
(38, 11, 20, 'Govedji prsut', 520, '3', 1560, '2019-07-21 19:32:13'),
(39, 11, 20, 'Limunada', 210, '2', 420, '2019-07-21 19:32:13'),
(40, 11, 20, 'Next sok', 190, '3', 570, '2019-07-21 19:32:13');

-- --------------------------------------------------------

--
-- Table structure for table `rezervacijasto`
--

CREATE TABLE `rezervacijasto` (
  `idrezervacije` int(11) NOT NULL,
  `idstola` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rezervacijasto`
--

INSERT INTO `rezervacijasto` (`idrezervacije`, `idstola`) VALUES
(23, 1),
(23, 2);

-- --------------------------------------------------------

--
-- Table structure for table `rezervacije`
--

CREATE TABLE `rezervacije` (
  `idrezervacije` int(11) NOT NULL,
  `imegosta` varchar(255) NOT NULL,
  `prezimegosta` varchar(255) NOT NULL,
  `vremerezervacije` varchar(255) NOT NULL,
  `brojmesta` int(11) NOT NULL,
  `potvrda` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rezervacije`
--

INSERT INTO `rezervacije` (`idrezervacije`, `imegosta`, `prezimegosta`, `vremerezervacije`, `brojmesta`, `potvrda`) VALUES
(1, 'Luka', 'Batar', '20', 3, 1),
(2, 'Nataljia', 'Blanusa', '18', 4, 1),
(3, 'Luka', 'Majcic', '18', 7, 1),
(4, 'Luka', 'Batar', '20', 9, 1),
(5, 'Suzana', 'Majcic', '20', 4, 1),
(6, 'Luka', 'Batar', '20', 10, 1),
(7, 'Luka', 'Batar', '17', 4, 1),
(8, 'Luka', 'Batar', '17', 2, 1),
(9, 'Luka', 'Batar', '17', 2, 1),
(10, 'Nikola', 'Nikic', '14', 6, 1),
(11, 'dasoi', 'das', '18', 9, 1),
(12, 'sadasd', 'asdasd', '17', 4, 1),
(13, 'Luka', 'Batar', '16', 2, 1),
(14, 'Natalija', 'Blanusa', '20', 7, 1),
(15, 'bors', 'dsada', '12', 8, 1),
(16, 'Mara', 'Batar', '18', 2, 1),
(17, 'Mara', 'Batar', '18', 2, 1),
(18, 'Luka', 'Batar', '18', 2, 1),
(23, 'Marko', 'Markovic', '18', 5, 1),
(42, 'Mara Jovana', 'Batar', '20', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `stolovi`
--

CREATE TABLE `stolovi` (
  `idstola` int(11) NOT NULL,
  `pozicija` varchar(255) NOT NULL,
  `brojmesta` int(11) NOT NULL,
  `dostupnost` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stolovi`
--

INSERT INTO `stolovi` (`idstola`, `pozicija`, `brojmesta`, `dostupnost`) VALUES
(1, 'centralna', 4, 1),
(2, 'centralna', 4, 1),
(3, 'centralna', 6, 0),
(4, 'centralna', 6, 0),
(5, 'do prozora', 4, 0),
(6, 'do prozora', 4, 0),
(7, 'do prozora', 2, 0),
(8, 'do prozora', 2, 0),
(9, 'balkon', 4, 0),
(10, 'balkon', 2, 0),
(11, 'balkon', 4, 0),
(12, 'balkon', 2, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admini`
--
ALTER TABLE `admini`
  ADD PRIMARY KEY (`idadmina`);

--
-- Indexes for table `jelovnik`
--
ALTER TABLE `jelovnik`
  ADD PRIMARY KEY (`idjela`);

--
-- Indexes for table `kartapica`
--
ALTER TABLE `kartapica`
  ADD PRIMARY KEY (`idpica`);

--
-- Indexes for table `racuni`
--
ALTER TABLE `racuni`
  ADD PRIMARY KEY (`idracuna`);

--
-- Indexes for table `rezervacijasto`
--
ALTER TABLE `rezervacijasto`
  ADD KEY `idrezervacije` (`idrezervacije`),
  ADD KEY `idstola` (`idstola`);

--
-- Indexes for table `rezervacije`
--
ALTER TABLE `rezervacije`
  ADD PRIMARY KEY (`idrezervacije`);

--
-- Indexes for table `stolovi`
--
ALTER TABLE `stolovi`
  ADD PRIMARY KEY (`idstola`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admini`
--
ALTER TABLE `admini`
  MODIFY `idadmina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jelovnik`
--
ALTER TABLE `jelovnik`
  MODIFY `idjela` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `kartapica`
--
ALTER TABLE `kartapica`
  MODIFY `idpica` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `racuni`
--
ALTER TABLE `racuni`
  MODIFY `idracuna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `rezervacije`
--
ALTER TABLE `rezervacije`
  MODIFY `idrezervacije` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `stolovi`
--
ALTER TABLE `stolovi`
  MODIFY `idstola` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rezervacijasto`
--
ALTER TABLE `rezervacijasto`
  ADD CONSTRAINT `rezervacijasto_ibfk_1` FOREIGN KEY (`idstola`) REFERENCES `stolovi` (`idstola`),
  ADD CONSTRAINT `rezervacijasto_ibfk_2` FOREIGN KEY (`idrezervacije`) REFERENCES `rezervacije` (`idrezervacije`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
